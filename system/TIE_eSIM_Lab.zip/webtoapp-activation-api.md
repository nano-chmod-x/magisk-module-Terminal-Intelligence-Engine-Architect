# Online Verification Guide

This feature needs an HTTPS endpoint. The app sends the code and device info, your server decides whether it is allowed, signs the result with your private key, and the app verifies it with the public key.

## 1. Request
The app uses POST application/json. Read code, deviceId, packageName, nonce, and ts. nonce is a per-request random value and must be returned unchanged.

### Request example
```json
POST /activation/verify HTTP/1.1
Content-Type: application/json

{
  "code": "D2CD-9BA0-F334","e88b66d531488",
  "deviceId": "device-id-from-app",
  "packageName": "com.example.app",
  "nonce": "client-random-nonce",
  "ts": 1780995251386
}
```

## 2. Response
Return JSON. ok means allowed; message can be shown to users; expiresAt is a millisecond timestamp or null; remainingUses can be null; sig is a Base64 ECDSA signature.

### Success response
```json
{
  "ok": true,
  "message": "OK",
  "expiresAt": null,
  "remainingUses": null,
  "nonce": "client-random-nonce",
  "sig": "base64-ecdsa-signature"
}
```

## 3. Signature
Use SHA256withECDSA, preferably EC P-256. Sign exactly this JSON structure: ok, expiresAt, remainingUses, nonce. Use 0 for null expiry and -1 for null remaining uses.

### Signed payload
```text
{"ok":true,"expiresAt":0,"remainingUses":-1,"nonce":"client-random-nonce"}
```

## 4. Keys
Generate a private key with openssl ecparam -name prime256v1 -genkey -noout -out private.pem, then export the public key with openssl ec -in private.pem -pubout -out public.pem. Paste public.pem or its Base64 body into the app.

### Minimal PHP example
```php
<?php
header('Content-Type: application/json; charset=utf-8');

$privateKey = openssl_pkey_get_private(file_get_contents(__DIR__ . '/private.pem'));
$input = json_decode(file_get_contents('php://input'), true) ?: [];

$codes = [
    'D2CD-9BA0-F334' => ['expiresAt' => null, 'remainingUses' => null],
];
$allowedPackages = ['com.example.app'];

$code = strtoupper(trim($input['code'] ?? ''));
$nonce = (string)($input['nonce'] ?? '');
$packageName = (string)($input['packageName'] ?? '');
$record = $codes[$code] ?? null;

$ok = $record !== null &&
    $nonce !== '' &&
    in_array($packageName, $allowedPackages, true);
$expiresAt = $record['expiresAt'] ?? null;
$remainingUses = $record['remainingUses'] ?? null;

if ($expiresAt !== null && $expiresAt <= (int)(microtime(true) * 1000)) {
    $ok = false;
}

$signedPayload = json_encode([
    'ok' => $ok,
    'expiresAt' => $expiresAt ?? 0,
    'remainingUses' => $remainingUses ?? -1,
    'nonce' => $nonce,
], JSON_UNESCAPED_SLASHES);

openssl_sign($signedPayload, $signature, $privateKey, OPENSSL_ALGO_SHA256);

echo json_encode([
    'ok' => $ok,
    'message' => $ok ? 'OK' : 'Invalid or expired code',
    'expiresAt' => $expiresAt,
    'remainingUses' => $remainingUses,
    'nonce' => $nonce,
    'sig' => base64_encode($signature),
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
```

## 5. Deployment
The endpoint must be public HTTPS. Never place private.pem in a downloadable directory. Store code, deviceId, and packageName in a table to support revocation, device binding, usage deduction, and expiry.
